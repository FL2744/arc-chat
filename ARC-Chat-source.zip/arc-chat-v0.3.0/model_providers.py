"""OpenAI-compatible model providers and endpoint/retry policy."""

from __future__ import annotations

import asyncio
import ipaddress
import json
import random
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Any, Mapping
from urllib.parse import urlsplit

from aiohttp import ClientConnectionError, ClientTimeout


ARC_ENDPOINT = "https://llm-api.arc.vt.edu/api/v1"
OPENAI_ENDPOINT = "https://api.openai.com/v1"


class EndpointPolicy:
    @staticmethod
    def validate(endpoint: str, *, allow_custom: bool = True, allow_loopback_http: bool = False) -> str:
        value = endpoint.rstrip("/")
        parsed = urlsplit(value)
        loopback_http = allow_loopback_http and parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if parsed.scheme != "https" and not loopback_http:
            raise ValueError("Model API URL must use HTTPS.")
        if not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Model API URL must contain a public HTTPS host without embedded credentials.")
        try:
            port = parsed.port
        except ValueError as exc:
            raise ValueError("Model API URL contains an invalid port.") from exc
        if port == 0:
            raise ValueError("Model API URL contains an invalid port.")
        host = parsed.hostname.lower().rstrip(".")
        if parsed.query or parsed.fragment:
            raise ValueError("Model API URL must not contain a query string or fragment.")
        if not loopback_http and (host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".localhost", ".internal", ".home.arpa"))):
            raise ValueError("Model API URL cannot target a local host.")
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            address = None
        if address and not loopback_http and (not address.is_global or address.is_multicast or address.is_unspecified or address.is_loopback or address.is_link_local):
            raise ValueError("Model API URL cannot target a non-global IP address.")
        # Reject ambiguous numeric host spellings (for example integer/hex IPv4)
        # that some resolvers reinterpret as local addresses after this parser.
        if address is None and (host.isdigit() or re_numeric_host(host)):
            raise ValueError("Model API URL cannot use an ambiguous numeric host.")
        if not allow_custom and value not in {ARC_ENDPOINT, OPENAI_ENDPOINT}:
            raise ValueError("This course profile only permits the configured model provider.")
        return value


def re_numeric_host(host: str) -> bool:
    lowered = host.lower()
    if lowered.startswith("0x"):
        return True
    labels = lowered.split(".")
    return bool(labels) and all(label and (label.isdigit() or label.startswith("0x")) for label in labels)


@dataclass(frozen=True)
class ModelCatalogEntry:
    id: str
    provider: str
    capabilities: tuple[str, ...] = ("tool_calling",)
    context_tokens: int | None = None
    concurrency: int | None = None
    reasoning_effort: str = ""


FALLBACK_CATALOG = (
    ModelCatalogEntry("gpt-oss-120b", "arc_shared", ("chat", "tool_calling", "reasoning"), 131072, 10, "medium"),
    ModelCatalogEntry("GLM-5.3", "arc_shared", ("chat", "tool_calling", "reasoning"), 131072, 4, "max"),
    ModelCatalogEntry("Kimi-K3", "arc_shared", ("chat", "tool_calling", "reasoning", "vision"), 131072, 3, "max"),
    ModelCatalogEntry("DeepSeek-V4.1-Flash", "arc_shared", ("chat", "tool_calling", "reasoning", "vision"), 524288, 10, "high"),
    ModelCatalogEntry("Qwen3-Embedding-4B", "arc_shared", ("embeddings",), 8192, 4),
)


class ModelCatalog:
    def __init__(self, entries: tuple[ModelCatalogEntry, ...] = FALLBACK_CATALOG):
        self.entries = entries

    def ids(self, provider: str | None = None) -> list[str]:
        return [entry.id for entry in self.entries if provider is None or entry.provider == provider]

    def get(self, model_id: str) -> ModelCatalogEntry | None:
        return next((entry for entry in self.entries if entry.id == model_id), None)

    @classmethod
    async def discover(cls, http, endpoint: str, key: str, *, provider: str = "arc_shared") -> "ModelCatalog":
        """Use OpenAI-compatible model discovery when available, else fallback.

        Discovery only establishes model IDs. Capability/context metadata is
        retained from the documented fallback where the ID is known.
        """
        endpoint = EndpointPolicy.validate(endpoint)
        try:
            async with http.get(
                endpoint + "/models",
                headers={"Authorization": "Bearer " + key},
                timeout=ClientTimeout(total=15),
                allow_redirects=False,
            ) as response:
                if response.status >= 400:
                    return cls()
                payload = await response.json()
        except (ClientConnectionError, OSError, asyncio.TimeoutError, ValueError, TypeError):
            return cls()
        values = payload.get("data", []) if isinstance(payload, Mapping) else []
        known = {entry.id: entry for entry in FALLBACK_CATALOG}
        entries = []
        for item in values:
            model_id = item.get("id") if isinstance(item, Mapping) else None
            if not isinstance(model_id, str) or not model_id.strip():
                continue
            entries.append(known.get(model_id) or ModelCatalogEntry(model_id, provider, ("chat",)))
        return cls(tuple(entries) or FALLBACK_CATALOG)


class OpenAICompatibleProvider:
    """Transport for an OpenAI-compatible chat-completions endpoint.

    Retries are limited to connection failures, HTTP 429, and transient 5xx
    responses. A request is never retried after a successful response, so a
    model tool call cannot be duplicated by this layer.
    """

    def __init__(self, http, endpoint: str, key: str, *, max_attempts: int = 3, sleep=asyncio.sleep, allow_loopback_http: bool = False):
        self.http = http
        self.endpoint = EndpointPolicy.validate(endpoint, allow_loopback_http=allow_loopback_http)
        self.key = key
        self.max_attempts = max(1, max_attempts)
        self.sleep = sleep

    async def complete(self, body: Mapping[str, Any]) -> dict[str, Any]:
        delay = 0.75
        last_error: Exception | None = None
        for attempt in range(self.max_attempts):
            try:
                async with self.http.post(
                    self.endpoint + "/chat/completions",
                    json=dict(body),
                    headers={"Authorization": "Bearer " + self.key},
                    timeout=ClientTimeout(total=180),
                    allow_redirects=False,
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    text = (await response.text())[:500]
                    if response.status not in {429, 500, 502, 503, 504} or attempt + 1 >= self.max_attempts:
                        raise RuntimeError(f"Model API HTTP {response.status}: {text}")
                    retry_after = self._retry_after(getattr(response, "headers", {}))
                    if retry_after is None and response.status == 429:
                        try:
                            body = json.loads(text)
                            error = body.get("error", {}) if isinstance(body, Mapping) else {}
                            retry_after = float(error.get("retry_after_s")) if error.get("retry_after_s") is not None else None
                        except (ValueError, TypeError, AttributeError):
                            retry_after = None
                    await self.sleep(min(30.0, retry_after if retry_after is not None else delay + random.uniform(0, 0.25)))
                    delay = min(30.0, delay * 2)
            except RuntimeError:
                raise
            except (ClientConnectionError, OSError, asyncio.TimeoutError) as exc:
                last_error = exc
                if attempt + 1 >= self.max_attempts:
                    raise RuntimeError("Model API is temporarily unreachable after bounded retries.") from exc
                await self.sleep(min(30.0, delay + random.uniform(0, 0.25)))
                delay = min(30.0, delay * 2)
        raise RuntimeError("Model API request failed.") from last_error

    @staticmethod
    def _retry_after(headers: Mapping[str, str]) -> float | None:
        value = headers.get("Retry-After") or headers.get("retry-after")
        if not value:
            return None
        try:
            return max(0.0, float(value))
        except ValueError:
            try:
                return max(0.0, (parsedate_to_datetime(value).timestamp() - __import__("time").time()))
            except (TypeError, ValueError, OverflowError):
                return None


class ArcSharedModelProvider(OpenAICompatibleProvider):
    def __init__(self, http, key: str, endpoint: str = ARC_ENDPOINT, **kwargs):
        super().__init__(http, endpoint, key, **kwargs)


class OpenAIModelProvider(OpenAICompatibleProvider):
    def __init__(self, http, key: str, endpoint: str = OPENAI_ENDPOINT, **kwargs):
        super().__init__(http, endpoint, key, **kwargs)


class CustomCompatibleProvider(OpenAICompatibleProvider):
    pass


class ManagedTunnelProvider(OpenAICompatibleProvider):
    def __init__(self, http, endpoint: str, key: str, **kwargs):
        super().__init__(http, endpoint, key, allow_loopback_http=True, **kwargs)


def build_provider(http, provider: str, endpoint: str, key: str) -> OpenAICompatibleProvider:
    if provider == "arc":
        return ArcSharedModelProvider(http, key, endpoint)
    if provider == "openai":
        return OpenAIModelProvider(http, key, endpoint)
    if provider == "custom":
        return CustomCompatibleProvider(http, endpoint, key)
    if provider == "managed":
        return ManagedTunnelProvider(http, endpoint, key)
    raise ValueError(f"Unsupported model provider: {provider}")
